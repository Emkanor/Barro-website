// Custom JavaScript can be added here.
console.log('Website is loaded and ready!');
